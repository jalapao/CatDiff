#include "filters.h"

QString myFilters =
        "C code(*.c *.cpp *.h *.cs *.m *.mm *.hpp);;java code(*.java *.jsp *.jsf);;assembly code(*.asm *.s);;web pages(*.html *.xml *.css *.php *.htm);;text(*.txt);;other(*.other)";
