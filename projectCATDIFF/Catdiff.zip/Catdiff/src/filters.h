#ifndef FILTERS_H
#define FILTERS_H
#include <QString>


extern QString myFilters;

#endif // FILTERS_H



